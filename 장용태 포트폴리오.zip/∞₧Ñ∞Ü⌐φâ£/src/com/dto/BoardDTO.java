package com.dto;

public class BoardDTO {

}
